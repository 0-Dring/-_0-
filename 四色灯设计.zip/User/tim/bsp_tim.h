#ifndef __BSP_ADVANCETIME_H
#define __BSP_ADVANCETIME_H

#include "stm32f10x.h"






void TIM3_Config(uint16_t arr,uint16_t psc);
void TIM5_Config(uint16_t arr,uint16_t psc);
#endif
