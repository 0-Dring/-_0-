// bsp ��board support package �弶֧�ְ�
#include "bsp_led.h"
#include "delay.h"
#include "bsp_i2c.h"
#include "bsp_tim.h"

extern  uint8_t n;
extern uint8_t i;
extern uint8_t x[2];

void LED_GPIO_Config(void)
{
	GPIO_InitTypeDef  GPIO_InitStruct;                 //����GPIO��ʼ�� �ṹ�� ����
	
	RCC_APB2PeriphClockCmd(LED0_GPIO_CLK | LED1_GPIO_CLK , ENABLE);//��Ӧ����ʱ��ʹ��
	
	GPIO_InitStruct.GPIO_Pin = LED0_GPIO_PIN;          //ѡ���ʼ��������
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;      //ѡ��ģʽ
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;     //ѡ���ٶ�
	GPIO_Init(LED0_GPIO_PORT, &GPIO_InitStruct);       //LED0
	GPIO_Init(LED1_GPIO_PORT, &GPIO_InitStruct);       //LED1
	GPIO_SetBits(LED0_GPIO_PORT,LED0_GPIO_PIN);
	GPIO_SetBits(LED1_GPIO_PORT,LED0_GPIO_PIN);
}

void BEEP_GPIO_Config(void)
{
	GPIO_InitTypeDef  GPIO_InitStruct;
	
	RCC_APB2PeriphClockCmd(BEEP_GPIO_CLK  , ENABLE);
	
	GPIO_InitStruct.GPIO_Pin = BEEP_GPIO_PIN;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(BEEP_GPIO_PORT, &GPIO_InitStruct);  
}
void KEY_GPIO_Config(void)
{
	GPIO_InitTypeDef  GPIO_InitStruct;
	
	RCC_APB2PeriphClockCmd(KEY_UP_GPIO_CLK | KEY0_GPIO_CLK | KEY1_GPIO_CLK , ENABLE);

	GPIO_InitStruct.GPIO_Pin = KEY_UP_GPIO_PIN;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_Init(KEY_UP_GPIO_PORT, &GPIO_InitStruct);  
	
	GPIO_InitStruct.GPIO_Pin = KEY0_GPIO_PIN | KEY1_GPIO_PIN;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIOE, &GPIO_InitStruct);  

	
}
uint8_t Key_Scan(GPIO_TypeDef *GPIOx,uint16_t GPIO_Pin)
{
	if(GPIO_ReadInputDataBit(GPIOx, GPIO_Pin) == 1)
	{
		
		while(GPIO_ReadInputDataBit(GPIOx, GPIO_Pin) == 1);
		
		return 1;
	}
	else return 0;
}
uint8_t Key_LED(GPIO_TypeDef *GPIOx,uint16_t GPIO_Pin)
{
	if(GPIO_ReadInputDataBit(GPIOx, GPIO_Pin) == 0)
	{
		
		while(GPIO_ReadInputDataBit(GPIOx, GPIO_Pin) == 0);
		
		return 0;
	}
	else return 1;
}
//������������
//���ذ���ֵ
//mode:0,��֧��������;1,֧��������;
//0��û���κΰ�������
//1��KEY0����
//2��KEY1����
//3��KEY3���� WK_UP
//ע��˺�������Ӧ���ȼ�,KEY0>KEY1>KEY_UP!!
uint8_t KEY_Scan(uint8_t mode)
{	 
	static uint8_t key_up=1;//�������ɿ���־
	if(mode)key_up=1;  //֧������		  
	if(key_up&&(KEY0==0||KEY1==0||KEY_UP==1))
	{
		delay_ms(20);//ȥ���� 
		key_up=0;
		if(KEY0==0)return KEY0_PRES;
		else if(KEY1==0)return KEY1_PRES;
		else if(KEY_UP==1)return KEY_UP_PRES;
	}else if(KEY0==1&&KEY1==1&&KEY_UP==0)key_up=1; 	    
 	return 0;// �ް�������
}
uc16 music1[78]={ //����1�����ݱ���������������ż���ǳ��ȣ�
330,750,
440,375,
494,375,
523,750,
587,375,
659,375,
587,750,
494,375,
392,375,
440,1500,
330,750,
440,375,
494,375,
523,750,
587,375,
659,375,
587,750,
494,375,
392,375,
784,1500,
659,750,
698,375,
784,375,
880,750,
784,375,
698,375,
659,750,
587,750,
659,750,
523,375,
494,375,
440,750,
440,375,
494,375,
523,750,
523,750,
494,750,
392,750,
440,3000
};

void MIDI_PLAY(void){ //MIDI����
	uint16_t i,e;
	for(i=0;i<39;i++)
	{
		for(e=0;e<(music1[i*2]*music1[i*2+1]/1000);e++)
		{
			
			GPIO_SetBits(BEEP_GPIO_PORT, BEEP_GPIO_PIN); //�������ӿ����0
			delay_us(500000/music1[i*2]); //��ʱ		
			GPIO_SetBits(BEEP_GPIO_PORT, BEEP_GPIO_PIN);
      GPIO_ResetBits(BEEP_GPIO_PORT, BEEP_GPIO_PIN);			//�������ӿ�����ߵ�ƽ1
			delay_us(500000/music1[i*2]); //��ʱ	
		}	
	}
}



void ks(void)
{
	EEPROM_I2C_Read(x,1,1);
	n=x[1];
	while(i == 7)
	{
		switch(n)
		{
			case 1:{PBout(5)=1;PEout(5)=1;PBout(8)=1;}break;
			case 2:{PBout(5)=1;PEout(5)=1;PBout(8)=0;}break;
      case 3:{PBout(5)=0;PEout(5)=1;PBout(8)=1;}break;
      case 4:{PBout(5)=0;PEout(5)=0;PBout(8)=1;}break;
      case 5:{PBout(5)=0;PEout(5)=1;PBout(8)=0;}break;
      case 6:{PBout(5)=1;PEout(5)=0;PBout(8)=1;}break;
      case 7:{PBout(5)=1;PEout(5)=0;PBout(8)=0;}break;
		}
		delay_ms(1500);
		n++;
		if(n>7) n=1;
		
	}
	  EEPROM_I2C_Write((n-1),1);
		EEPROM_WaitFoeWriteEnd();
}

void ms(void)
{
	u32 temp=0;
  uint8_t v=1,t=1;
	TIM3_Config(899,0);
	while(1)
	{
		delay_ms(10);
		if(t==1) temp++;
		else     temp--;
		switch(v)
		{
			case 1:{TIM_SetCompare1(TIM3,temp);TIM_SetCompare2(TIM3,0);}break;
			case 2:{TIM_SetCompare1(TIM3,0);TIM_SetCompare2(TIM3,temp);}break;
		}
		if(temp>300) t=0;
    if(temp==0) t=1,v++;
		if(v>2)v=1;
	}
	
}


