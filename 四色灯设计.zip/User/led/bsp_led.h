#ifndef __BSP_LED_H
#define __BSP_LED_H

#include "stm32f10x.h"

#define LED0_GPIO_PORT             GPIOB
#define LED1_GPIO_PORT             GPIOE
#define BEEP_GPIO_PORT             GPIOB
#define KEY_UP_GPIO_PORT           GPIOA
#define KEY0_GPIO_PORT             GPIOE
#define KEY1_GPIO_PORT             GPIOE

#define LED0_GPIO_PIN              GPIO_Pin_5
#define LED1_GPIO_PIN              GPIO_Pin_5
#define BEEP_GPIO_PIN              GPIO_Pin_8
#define KEY_UP_GPIO_PIN            GPIO_Pin_0
#define KEY0_GPIO_PIN              GPIO_Pin_4
#define KEY1_GPIO_PIN              GPIO_Pin_3

#define LED0_GPIO_CLK              RCC_APB2Periph_GPIOB
#define LED1_GPIO_CLK              RCC_APB2Periph_GPIOE
#define BEEP_GPIO_CLK              RCC_APB2Periph_GPIOB
#define KEY_UP_GPIO_CLK            RCC_APB2Periph_GPIOA
#define KEY0_GPIO_CLK              RCC_APB2Periph_GPIOE
#define KEY1_GPIO_CLK              RCC_APB2Periph_GPIOE

#define  KEY_UP                    GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0)
#define  KEY0                      GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_4)
#define  KEY1                      GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_3)

#define KEY0_PRES 	1	//KEY0����
#define KEY1_PRES	  2	//KEY1����
#define KEY_UP_PRES   3	//KEY_UP����(��WK_UP/KEY_UP)

#define KEY_UP_BEEP              {BEEP_GPIO_PORT->ODR ^= BEEP_GPIO_PIN;}
#define KEY0_LED0                {LED0_GPIO_PORT->ODR ^= LED0_GPIO_PIN;}
#define KEY1_LED1                {LED1_GPIO_PORT->ODR ^= LED1_GPIO_PIN;}
// \  C������������з������治�����κεĶ���

void LED_GPIO_Config(void);
void BEEP_GPIO_Config(void);
void KEY_GPIO_Config(void);
uint8_t Key_Scan(GPIO_TypeDef *GPIOx,uint16_t GPIO_Pin);
uint8_t Key_LED(GPIO_TypeDef *GPIOx,uint16_t GPIO_Pin);
uint8_t KEY_Scan(uint8_t mode);
void ks(void);
void ms(void);
#endif /* __BSP_LED_H */

