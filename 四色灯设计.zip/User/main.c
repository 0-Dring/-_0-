#include "stm32f10x.h"   // �൱��51��Ƭ���е�  #include <reg51.h>
#include "bsp_led.h"
#include "bsp_rccclkconfig.h"
#include "delay.h"
#include "bsp_usart.h"
#include "bsp_i2c.h"
#include "bsp_i2c_ee.h"
#include "wkup.h"
#include "bsp_tim.h"

uint8_t x[2]={0};
uint8_t i=0;
uint8_t n=0;
void Delay( uint32_t count )
{
	for(; count!=0; count--);
}

int main(void)
{
	delay_init();
	LED_GPIO_Config();
	KEY_GPIO_Config();
	BEEP_GPIO_Config();
	I2C_EE_Config();
  USART_Config();
	WKUP_Init();
	printf("i=%d",i);
	EEPROM_I2C_Read(x,0,1);
	i=x[0];
	while(1)
	{
		if(i>6) i=0;
		printf("i=%d",i);
		EEPROM_I2C_Write(i,0);
		EEPROM_WaitFoeWriteEnd();
		
		switch(i)
		{
			case 0:{PBout(5)=1;PEout(5)=1;PBout(8)=1;}break;
			case 1:{PBout(5)=1;PEout(5)=1;PBout(8)=0;}break;
      case 2:{PBout(5)=0;PEout(5)=1;PBout(8)=1;}break;
      case 3:{PBout(5)=0;PEout(5)=0;PBout(8)=1;}break;
      case 4:{PBout(5)=0;PEout(5)=1;PBout(8)=0;}break;
      case 5:{PBout(5)=1;PEout(5)=0;PBout(8)=1;}break;
      case 6:{PBout(5)=1;PEout(5)=0;PBout(8)=0;}break;
//			case 7:{ks();}break;
//			case 8:{ms();}break;
		}
  }
}

// ��ҵ

// 1��ʹ�ù̼����̵ķ�ʽ����ʣ�µ�����LED��Ҳ��������ʵ����ˮ�Ƶ���ʽ
